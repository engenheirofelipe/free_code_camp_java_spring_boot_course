#	Step by step

	*	Initializing project with MAVEN
	
	1.	Go to INITLZ web, select spring web and spring developer tools dependencies.
	2.	Add names of the project and download ZIP project.
	
	*	Imported project at eclipse
	
	1.	Rename RUNNERZ application, at SRC/main/java
	2.	Class application is where contains main method.
	3.	Create a package from java folder.
	4.	Create a class inside the default package.
	5.	At Application class :
	
		add @ComponentScan(basedPackeges = {org.freecodecamp.run, org.freecodecamp.runnerz}) -> Ensure that the packages are scanned.
	
		add ConfigurableApplication context -> Is a huge container that getters all the classes. And we can aks application context for a particular classes
		Instanciate WelcomeMessage
		
	6. Delete step 5
	
	*	netstat -a -o | findstr :8080 -> Command to see what processes is listening
	*	tasklist | findstr 16008 -> COMMAND TO SEE(PID)
	
	*	Class ENUM Location : It has specific values we can pick from.
	
	*	CommandLineRunner is just something that runs after the application has started. And more important,
	after the application context has been created.
	

	
##	Starting building the web application

#	MVC

	1.	MODEL -> Is the type we are going to work with. In this case run and location is the model
	2.	VIEW -> Is how we are going to represent this thing in our system. In this case the view is going to be JSON returned as data.
	3. Controller -> Take in a request, return a response.

	*	We have a embedded	 web server TOMCAT.
	
	1.	Creating a class called RunController. (Annotations add behaviors to a class)
	2.	Annotation @RestController, brings the JSON format
	2.	If somebody access an ENDPOINT, so run that method, beneath @GetMapping.
	
	