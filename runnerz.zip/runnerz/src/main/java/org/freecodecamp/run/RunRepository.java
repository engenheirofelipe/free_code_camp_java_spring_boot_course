package org.freecodecamp.run;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import jakarta.annotation.PostConstruct;

@Repository
public class RunRepository {
	
	private List<Run> runs = new ArrayList<>();
	
	/*Return a list of runs*/
	List<Run> findAll(){
		return runs;
	}
	
	@PostConstruct
	public void init() {
		
		runs.add(new Run(1,"Afternoon", LocalDateTime.now(), LocalDateTime.now().plus(30,ChronoUnit.MINUTES), 3, Location.INDOOR));
		runs.add(new Run(2, "Night", LocalDateTime.now(), LocalDateTime.now().plus(60, ChronoUnit.MINUTES), 5, Location.INDOOR));
		runs.add(new Run(3, "Overall", LocalDateTime.now(), LocalDateTime.now().plus(80, ChronoUnit.MINUTES), 8, Location.INDOOR));
		runs.add(new Run(4, "Day", LocalDateTime.now(), LocalDateTime.now().plus(70, ChronoUnit.MINUTES), 6, Location.INDOOR));
		runs.add(new Run(5, "Friday", LocalDateTime.now(), LocalDateTime.now().plus(60, ChronoUnit.MINUTES), 7, Location.INDOOR));
		runs.add(new Run(6, "Monday", LocalDateTime.now(), LocalDateTime.now().plus(50, ChronoUnit.MINUTES), 9, Location.INDOOR));
		runs.add(new Run(7, "Saturday", LocalDateTime.now(), LocalDateTime.now().plus(70, ChronoUnit.MINUTES), 4, Location.INDOOR));
		
	}


	/* Method findById */
	Optional <Run> findById(Integer id) {
		
		return runs.stream()
				.filter(run -> run.id() == id)
				.findFirst();
	}
	
	void create(Run run) {
		
		runs.add(run);
		
	}
		
}


