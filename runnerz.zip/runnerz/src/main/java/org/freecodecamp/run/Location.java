package org.freecodecamp.run;

public enum Location {
	
	INDOOR, OUTDOOR;

}
