package org.freecodecamp.run;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class RunController {

	private final RunRepository runRepository;

	public RunController(RunRepository runRepository) {
		this.runRepository = runRepository;
	}

	/* Map API route and bring all the runs*/
	@GetMapping("/api/runs")
	List<Run> findAll() {
		return runRepository.findAll();
	}
	
	/* Map the id and bring a specific run*/
	@GetMapping("/{id}")
	Run findById(@PathVariable Integer id) {
		
		Optional<Run> run = runRepository.findById(id);
		
		if(run.isEmpty()) {
			
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Run not found");
			
		}
		return run.get();
		
	}
	
	// Post
	@ResponseStatus(HttpStatus.CREATED)
	@PostMapping("")
	void create(@RequestBody Run run) {
		runRepository.create(run);
	}
	
	// Put
	
	
	
}
	